// Inject a script to the DOM
function injectScript() {
    const script = document.createElement('script');
    script.src = chrome.runtime.getURL('bundle.js'); // Reference bundled React app
    script.type = 'module'; // Use type="module" to load ES6 code
    document.body.appendChild(script);
  }
  
  injectScript();
  