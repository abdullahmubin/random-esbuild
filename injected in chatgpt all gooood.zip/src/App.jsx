import React from 'react';

const App = () => (
  <div style={{ backgroundColor: 'lightblue', padding: '10px' }}>
    <h1>Hello from React!</h1>
    <p>Test with again. with observe</p>
    <button onClick={() => alert('Button clicked!')}>Click Me</button>
  </div>
);

export default App;
