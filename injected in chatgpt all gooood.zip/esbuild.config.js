const esbuild = require('esbuild');

esbuild.build({
  entryPoints: ['./src/content.jsx'],
  bundle: true,
  outfile: './dist/content.js',
  platform: 'browser',
  target: ['chrome58'],
  minify: true,
  logLevel: 'info'
}).catch(() => process.exit(1));
